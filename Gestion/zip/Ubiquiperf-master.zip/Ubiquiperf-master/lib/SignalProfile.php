<?php
class SignalProfile
{
    public $Timestamp;
    public $RSSI;
    public $Signal;
    public $NoiseFloor;
    public $ChWidth;
    public $Throughput;
    public $FWversion;
    public $Frequency;
    public $Channel;
    public $Ack;
    public $Distance;
    public $ccq;
    public $txrate;
    public $rxrate;
    public $quality;
    public $capacity;
    public $OpMode;
    public $ChainRSSI0;
    public $ChainRSSI1;
    public $txretries;
}
?>
