<?php

namespace PHPUnit\Framework;

// Only needed to keep unit test code compatible with older PHPUnit versions

/** @noinspection PhpUndefinedClassInspection */
/** @noinspection AutoloadingIssuesInspection */
class TestCase extends \PHPUnit_Framework_TestCase {

}
