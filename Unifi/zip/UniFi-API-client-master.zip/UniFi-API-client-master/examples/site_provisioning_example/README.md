## Site provisioning script

Contributed by @smos

This directory contains an example provisioning script to create a large number of sites with comparable network configurations. It sets the LAN config to site specific configuration. Copy the settings.template.php and config.template.php to their respective files for testing.
This is meant as a basic provisioning only system. Currently used against controller 5.6.30.

## Important Disclaimer

Use all examples at your own risk!