<?php

session_start();

$allowtime = 120;			// Default 120 duration of the authorization if not sett in the client-config.php
$connectionTime = "2000";		// 2 sec defult if not set in server-config.php
include 'client-config.php';            // Seting Allowtime, quota, etc.
include 'server-config.php';

function sendAuthorization($id, $minutes, $bytes, $down, $up, $ap_mac)
{
#$unifiServer = "https://<ip>:8443";     // Config in server-config.php
#$unifiUser = "<user>";                  // Config in server-config.php
#$unifiPass = "<password>";              // Config in server-config.php
include 'server-config.php';

// Start Curl for login
$ch = curl_init();
// We are posting data
//curl_setopt($ch, CURLOPT_RETURNTRANSFER, FALSE);
curl_setopt($ch, CURLOPT_POST, TRUE);
// Set up cookies
$cookie_file = "/tmp/unifi_cookie";
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file);
// Allow Self Signed Certs
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
// Force SSL3 only
curl_setopt($ch, CURLOPT_SSLVERSION, 1);
// Login to the UniFi controller
curl_setopt($ch, CURLOPT_URL, "$unifiServer/api/login");
$data = json_encode(array("username" => $unifiUser, "password" => $unifiPass));
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

// curl_setopt($ch, CURLOPT_POSTFIELDS, "login=login&username=$unifiUser&password=$unifiPass");
// send login command
curl_exec ($ch);
echo "Checkpoint 1";
// Send user to authorize and the time allowed
$data = json_encode(array(
'cmd'=>'authorize-guest',
'mac'=>$id,
'minutes'=>$minutes,
'bytes'=>$bytes,
'down'=>$down,
'up'=>$up,
'ap_mac'=>$ap_map));
// Send the command to the API
// curl_setopt($ch, CURLOPT_URL, $unifiServer.'/api/cmd/stamgr');
curl_setopt($ch, CURLOPT_URL, $unifiServer . "/api/s/{$_SESSION['siteurl']}/cmd/stamgr");
curl_setopt($ch, CURLOPT_POSTFIELDS, 'json='.$data);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_exec ($ch);

//$result = json_decode(curl_exec($ch));
//return $result;

// Logout of the UniFi Controller
curl_setopt($ch, CURLOPT_URL, $unifiServer.'/logout');
curl_exec ($ch);
curl_close ($ch);
unset($ch);
}


if ($_SESSION['loggingin'] == "unique33ffw4hh6code") // Check to see if the form has been posted to
{
ob_start();
SendAuthorization($_SESSION['id'], $allowtime, $quota, $down_bandwith, $up_bandwith, $ap_macaddress); //authorizing user for X minutes
ob_end_clean();
#echo "<br>authorizing client<br>";	// Fore debug, Did I try to authorize client ?
unset($_SESSION['loggingin']);
}
$_SESSION['loopcunt'] = $_SESSION['loopcunt'] + 1;

?>
<div class="text">
<center>CONNECTING TO INTERNET...<br />
Please wait !</center>
</div>

<script>
//allow time for the authorization to go through
setTimeout("location.href='<?php echo $_SESSION['refURL'] . "'\"," . $connectionTime; ?>);
</script>
