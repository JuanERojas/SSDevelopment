<?php
#$allowtime = "60";		// Duration of the authorization in minutes
#$_SESSION['refURL'] = "http://example.com"; // Uncommet to set Promotional URL (Over overrated client first URL)
#$quota = "100";		// Uncommet to set DL quota for client in MB
#$down_bandwith = "1024";	// Uncommet to set client max kbps down speed
#$up_bandwith = "1024";		// Uncommet to set client max kbps up speed
#$ap_macaddress = "24:a4:3c:xx:xx:xx";	// Uncommet to Lock Client to one AP
