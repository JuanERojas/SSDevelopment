<?php
//PHP SCRIPT FOR SIMPLE PORTAL
//REQUIREMENTS:
//curl needs to be enabled (php_curl.dll for widnows)
#ini_set('session.gc_maxlifetime', 6);
#session_set_cookie_params(6);
session_start();

$_SESSION['id'] = $_GET['id'];          //user's mac address
$_SESSION['ap'] = $_GET['ap'];          //AP mac
$_SESSION['ssid'] = $_GET['ssid'];      //ssid the user is on (POST 2.3.2)
$_SESSION['time'] = $_GET['t'];         //time the user attempted a request of the portal
$_SESSION['refURL'] = $_GET['url'];     //url the user attempted to reach
$rest = $_SERVER['REQUEST_URI'];
preg_match('@^(?:/guest/s/)?([^/]+)@i', $rest, $matches);
$_SESSION['siteurl'] = $matches[1];
#echo "SiteID: {$_SESSION['siteurl']}<br>"; //SiteID debug

if ($_SESSION['loopcunt'] > "10") {unset($_SESSION['loopcunt']);}
if ($_SESSION['loopcunt'] == null ) {$_SESSION['loggingin'] = "unique33ffw4hh6code";}  // -- prevents them from simply going to /authorized.php on their own
if ($_SESSION['loopcunt'] > "0") {
echo "<head>";
echo "    <meta charset=\"utf-8\">";
echo "    <title>Portal Page Example</title>";
echo "</head>";
#echo "<center>Tilrun {$_SESSION['loopcunt']} til að tengjast";  // Icelandic
echo "<center>Connection attempt {$_SESSION['loopcunt']}";  // Englis
echo "<script>";
echo "setTimeout(\"location.href='authorized.php'\",500)";
echo "</script>";
}
else 
{
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Portal Page Example</title>
</head>

<body>
    <form name="login" action="authorized.php" method="post">
    <input id="submit" type="submit" name="submit" value="Connect" /> 
    </form>
</body>
</html>
<?php
}
