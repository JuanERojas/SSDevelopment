<?php
$unifiServer = "https://<ip>:8443";     // Config in server-config.php
$unifiUser = "<user>";                  // Config in server-config.php
$unifiPass = "<password>";              // Config in server-config.php
#$connectionTime = "2000";               // 2 sec defult
